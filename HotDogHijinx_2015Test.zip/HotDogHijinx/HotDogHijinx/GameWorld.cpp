#include "GameWorld.h"
#include <stdlib.h>
#include <time.h>

float GameWorld::activeTime = 0;
GLuint GameWorld::shaderProgramIndex = -1;
bool GameWorld::mouseButtonHeld = false;
vector<GameObject*> GameWorld::gameObjectPtrCollection = vector<GameObject*>(0);
vector<Shape*> GameWorld::shapePtrCollection = vector<Shape*>(0);

void GameWorld::update(void)
{
	float dt = getFrameTime();

	//Update all moveable objects

	/* UPDATE GAME OBJECTS */
	WallCollider wall;

	int n = gameObjectPtrCollection.size();
	for (int i = 0; i < n; i++)
	{
		gameObjectPtrCollection[i]->update(dt);
		Sphere* testSphere = new Sphere(.28575f, gameObjectPtrCollection[i]->getPosition());

		if (wall.collidesWithSphere(testSphere))
		{
			vec3 newVel = gameObjectPtrCollection[i]->getVelocity();
			newVel *= -1.0f;
			gameObjectPtrCollection[i]->setVelocity(newVel);
		}
	}

}


void GameWorld::draw(void)
{
	glClear(GL_COLOR_BUFFER_BIT);

	//Draw all visible objects
	int n = gameObjectPtrCollection.size();
	for (int i = 0; i < n; i++)
	{
		gameObjectPtrCollection[i]->draw();
	}

	glFlush();
}


bool GameWorld::init()
{
	glewExperimental = GL_TRUE;
	if (glewInit() != GLEW_OK) return false;

	// Time
	activeTime = float(glfwGetTime());

	// Background Color
	glClearColor(0.392f, 0.584f, 0.929f, 1.0f);

	// Load Shaders
	shaderProgramIndex = ShaderHelper::loadShaderProgram("Shaders/vertexShader.glsl", "Shaders/fragmentShader.glsl");

	if (shaderProgramIndex == 0)
	{
		cout << "Shaders failed to load." << endl;
		return false;
	}
	else
	{
		glUseProgram(shaderProgramIndex);
	}

	// Make triangle shape
	const GLsizei numVert = 3; /* Set to 3 for now */
	const GLsizei numVal = numVert * 5;
	GLfloat vertices[numVal] =
	{
		-0.125f, -0.125f, 0.1f, 0.1f, 0.1f, // the first point
		0.000f,  0.125f, 0.9f, 0.9f, 0.9f, // the second point
		0.125f, -0.125f, 0.5f, 0.5f, 0.5f, // the third point
	};
	shapePtrCollection.push_back(new Shape(vertices, numVert, shaderProgramIndex));

	return true;
}


void GameWorld::mouseClick(GLFWwindow* window, int button, int action, int mods)
{
	// Press Left Click
	if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_PRESS)
	{
		mouseButtonHeld = true;
	}
	else
	{
		mouseButtonHeld = false;
	}
}


void GameWorld::mouseMove(GLFWwindow* window, double x, double y)
{
	vec2 currentPosition = getCursorPos(window);

	// More code here

	if (mouseButtonHeld)
	{

		int i = shapePtrCollection.size();
		gameObjectPtrCollection.push_back(new GameObject(shapePtrCollection[i - 1],			//Shape:			Triangle
			vec3(getCursorPos(window), 0),		//Location:			Origin
			.163f,								//Mass:				163 grams (stored in units of kg)
			vec3(0, 0, 0),						//Velocity:			Not moving
			.28575f,							//Radius			Should be 28.575 mm, but we would need a projection/camera matrix to go from those units to screen coordinates
			vec3(0, 0, 1),						//Rotation Axis:	z-axis
			0,									//Rotation Angle:	0 degrees
			vec3(1, 1, 1),						//Color:			White
			0.0f));								//Angular Velocity

												/* Initialize random seed */
		srand(static_cast <unsigned> (time(0)));

		// Random Velocity
		int rX = rand() % 2000 - 1000;
		float randX = (float)rX / 1000;
		int rY = rand() % 2000 - 1000;
		float randY = (float)rY / 1000;
		vec3 randVel = vec3(randX, randY, 0);

		gameObjectPtrCollection.back()->setVelocity(randVel);

		// Random Angular Velocity
		int randAngle = rand() % 10000 - 10000;
		float angleVel = (float)randAngle / 1000;

		gameObjectPtrCollection.back()->setAnglularVelocity(angleVel);
	}
}

vec2 GameWorld::getCursorPos(GLFWwindow* window)
{
	double xpos, ypos;
	glfwGetCursorPos(window, &xpos, &ypos);
	int width, height;
	glfwGetWindowSize(window, &width, &height);
	vec2 cursorPosition;
	cursorPosition.x = 2.0f * ((float)xpos / (float)width) - 1.0f;
	cursorPosition.y = (2.0f * ((float)ypos / (float)height) - 1.0f) * -1.0f;

	return cursorPosition;
}

float GameWorld::getFrameTime()
{
	float currentTime = float(glfwGetTime());
	float dt = currentTime - activeTime;
	activeTime = currentTime;
	return dt;
}

GameWorld::GameWorld(void)
{
}


GameWorld::~GameWorld(void)
{
	int n = gameObjectPtrCollection.size();
	for (int i = 0; i < n; i++)
	{
		delete gameObjectPtrCollection[i];
	}

	n = shapePtrCollection.size();
	for (int i = 0; i < n; i++)
	{
		delete shapePtrCollection[i];
	}
}
