#include "WallCollider.h"


WallCollider::WallCollider()
{
}


WallCollider::~WallCollider(void)
{
}

bool WallCollider::collidesWithSphere(Sphere* other)
{
	vec3 triPos = other->getPosition();
	if (triPos.x < -1.0f || triPos.x > 1.0f || triPos.y > 1.0f || triPos.y < -1.0f) return true;

	else return false;
}
