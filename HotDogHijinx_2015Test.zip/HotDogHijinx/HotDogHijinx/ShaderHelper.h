#pragma once
#include <glew.h>
#include <glm\glm.hpp>
#include <iostream>
#include <fstream>

class ShaderHelper
{
public:
	ShaderHelper(void);


	static char* loadTextFile(const char* file);
	static GLuint loadShader(const char* file, GLenum shaderType);
	static GLuint loadShaderProgram(const char* vertexFile, const char* fragmentFile);

private:
	void setShaderColor(GLuint shaderIndex, const char* uniVar, float red, float green, float blue);
	void setShaderVec2(GLuint shaderIndex, const char* uniVar, glm::vec2 vecToSend);
	void setShaderMatrix(GLuint shaderIndex, const char* uniVar, glm::mat4& matToSend);
};
