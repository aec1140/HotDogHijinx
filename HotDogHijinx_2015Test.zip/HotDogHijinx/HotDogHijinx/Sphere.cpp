#include "Sphere.h"


Sphere::Sphere(float radius, vec3 position)
{
	this->radius = radius;
	this->position = position;
}


Sphere::~Sphere(void)
{
}

float Sphere::getRadius()
{
	return this->radius;
}

vec3 Sphere::getPosition()
{
	return this->position;
}