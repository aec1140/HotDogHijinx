#include "GameObject.h"

GameObject::GameObject(Shape* shapePtr, vec3 position, float mass, vec3 velocity, float scale,  vec3 rotationAxis, float rotationAmount, vec3 color, float angularVelocity)
{
	this-> position				= position;
	this-> mass 				= mass;
	this-> velocity				= velocity;
	this-> shapePtr				= shapePtr;
	this-> scale				= scale;
	this-> rotationAxis			= rotationAxis;
	this-> rotationAmount		= rotationAmount;
	this-> color				= color;
	this-> force				= vec3(0.0f, 0.0f, 0.0f);
	this-> textured				= false;
	this-> minVelocity			= .01f;
	this-> maxVelocity			= 1.0f;
	this-> angularVelocity		= angularVelocity;
}


void GameObject::update(float dt)
{
	// GRAVITY
	if(length(velocity) > maxVelocity)
	{
		velocity = normalize(velocity) * maxVelocity; /* if velocity is larger than maxVelocity */
	}
	velocity += force	 * dt / mass;
	position += velocity * dt;

	if(position.y >= -1.0f)
	{
		force = vec3(0.0f, -0.098f, 0.0f);
	}
	else
	{
		force = vec3(0.0f, 0.0f, 0.0f);
	}
	if(length(velocity) < minVelocity)
	{
		velocity = vec3(0.0f, 0.0f, 0.0f);
	}
	addForce(getVelocity() * -0.10f);

	// ROTATIONAL VELOCITY
	rotationAmount += angularVelocity * dt;

}

void GameObject::draw()
{
	shapePtr-> draw(position, vec3(scale, scale, scale), rotationAxis, rotationAmount, color, textured);
}

float GameObject::getScale()
{
	return scale;
}

float GameObject::getMass()
{
	return mass;
}

void GameObject::setVelocity(vec3 velocity)
{
	this-> velocity = velocity;
}

vec3 GameObject::getVelocity()
{
	return velocity;
}

void GameObject::addForce(vec3 force)
{
	this->force += force;
}

void GameObject::setPosition(vec3 position)
{
	this-> position = position;
}

vec3 GameObject::getPosition()
{
	return this-> position;
}

void GameObject::setVisable(bool visable)
{
	this-> visable = visable;
}

bool GameObject::getVisable()
{
	return this-> visable;
}

void GameObject::setTextured(bool textured)
{
	this-> textured = textured;
}

float GameObject::getMinVelocity()
{
	return this-> minVelocity;
}

void GameObject::setAnglularVelocity(float velocity)
{
	this-> angularVelocity = velocity;
}

GameObject::GameObject(void)
{
}


GameObject::~GameObject(void)
{
}
