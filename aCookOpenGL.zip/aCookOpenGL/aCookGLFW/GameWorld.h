#pragma once
#include <glew.h>
#include <iostream>
#include "ShaderHelper.h"
#include <glm\glm.hpp>
#include <glm\gtx\transform.hpp>
#include "GameObject.h"
#include <vector>
#include <SOIL.h>
#include "Sphere.h"
#include "WallCollider.h"

using namespace std;
using namespace glm;

#define GLFW_INCLUDE_GLU
#include <glfw3.h>

class GameWorld
{
public:
	
	static void update(void);
	static void draw(void);
	static bool init(void);
	static void mouseClick(GLFWwindow* window, int button, int action, int mods);
	static void mouseMove(GLFWwindow* window, double x, double y);
	static vec2 getCursorPos(GLFWwindow* window);

private:
	static float getFrameTime();
	static float activeTime;
	static GLuint shaderProgramIndex;

	static bool mouseButtonHeld;
	static vector<Shape*> shapePtrCollection;
	static vector<GameObject*> gameObjectPtrCollection;


	GameWorld(void);
	~GameWorld(void);
};

