#include "Shape.h"

void Shape::draw(	vec3 currentPosition,
					vec3 currentScale,
					vec3 rotationAxis,
					float rotationAngle,
					vec3 color,
					bool textured)
{
	mat4 worldMatrix =	translate(currentPosition) *
						scale(currentScale) *
						rotate(rotationAngle, rotationAxis);

	glProgramUniformMatrix4fv(program, uniformWorldMatrixLocation, 1, GL_FALSE, &worldMatrix[0][0]);
	glProgramUniform1i(program, uniformTexturedLocation, textured);
	glProgramUniform4f(program, uniformColorLocation, color.r, color.g, color.b, 1);

	glBindVertexArray(vaoIndex);

	glDrawArrays(	GL_TRIANGLES,
					0,
					numVerts		);
}

Shape::Shape(GLfloat vertexData[], GLsizei numVerts, GLuint program)
	: numVerts(numVerts)
	, floatsPerVert(5)
	, numFloats(numVerts * 5)
{
	this-> program = program;

	//Get locations of uniform variables
	uniformWorldMatrixLocation = glGetUniformLocation(program, "worldMatrix");
	uniformColorLocation =		 glGetUniformLocation(program, "uniformColor");
	uniformTexturedLocation =    glGetUniformLocation(program, "texturedObject");

	//Vertex Array
	glGenVertexArrays(1, &vaoIndex);
	glBindVertexArray(vaoIndex);

	//Buffers
	glGenBuffers(1, &vboIndex);
	glBindBuffer(GL_ARRAY_BUFFER, vboIndex);

	//Upload X,Y,R,G,B (vertex data)
	glBufferData(	GL_ARRAY_BUFFER,
					sizeof(GL_FLOAT) * numFloats,
					vertexData,
					GL_STATIC_DRAW		);

	// X, Y
	glVertexAttribPointer(	0,
							2,
							GL_FLOAT,
							GL_FALSE,
							sizeof(GL_FLOAT) * floatsPerVert,
							0			);

	glEnableVertexAttribArray(0);
	
	// R, G, B
	glVertexAttribPointer(
		1,								// The index of the attribute - 1 since it's the next one
		3,								// The number of components for this attribute - The next 4 are the color (r,g,b,a)
		GL_FLOAT,						// The type of data, so OpenGL knows how big each component is
		GL_FALSE,						// We don't want our data to be normalized
		sizeof(GL_FLOAT) * floatsPerVert,			// The stride (in bytes) between each of these attributes - 6 since pos (2) + color(4) = 6 total
		(void*)(sizeof(GL_FLOAT) * 2));	// An offset to the beginning of the first one of these attributes, as a pointer (this is ugly, but it works)

	glEnableVertexAttribArray(1);
}

Shape::Shape(void)
	: numVerts(0)
	, floatsPerVert(3)
	, numFloats(0 * 3)
{
}


Shape::~Shape(void)
{
	glDeleteVertexArrays(1, &vaoIndex);
	glDeleteBuffers(1, &vboIndex);
}
