/* ALEX COOK OPEN GL REVIEW */

#include "WindowManager.h"


int main()
{
	WindowManager::init();

    return 0;
}