#pragma once
#include <glm\glm.hpp>
using namespace glm;

class Sphere
{
public:
	float getRadius();
	vec3 getPosition();

	Sphere(float radius, vec3 position);
	~Sphere(void);

private:
	float radius;
	vec3 position;
};

