#pragma once
#include <glm\glm.hpp>
#include "Sphere.h"

using namespace glm;

class WallCollider
{
public:
	bool collidesWithSphere(Sphere* other);

	WallCollider();
	~WallCollider(void);

};

