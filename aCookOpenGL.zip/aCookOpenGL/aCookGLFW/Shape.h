#pragma once
#include <glew.h>
#include <glm\glm.hpp>
#include <glm\gtx\transform.hpp>
using namespace glm;

class Shape
{
public:
	Shape(GLfloat vertices[], GLsizei numVerts, GLuint program);

	void draw(	vec3 currentPosition,
				vec3 currentScale,
				vec3 rotationAxis,
				float rotationAngle,
				vec3 color,
				bool textured);

	~Shape(void);


private:
	GLuint vboIndex;
	GLuint vaoIndex;
	GLsizei const numVerts;
	int const floatsPerVert;
	GLsizei const numFloats;

	GLuint program;
	GLint uniformColorLocation, uniformWorldMatrixLocation, uniformTexturedLocation;

	Shape(void);
};

