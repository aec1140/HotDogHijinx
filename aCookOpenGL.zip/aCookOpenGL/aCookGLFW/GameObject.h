#pragma once
#include "Shape.h"
#include <glm\glm.hpp>
using namespace glm;

class GameObject
{
public:
	float getScale();
	void update(float dt);
	void draw();
	void addForce(vec3 force);
	float getMass();
	void setVelocity(vec3 velocity);
	vec3 getVelocity();
	void setPosition(vec3 position);
	vec3 getPosition();
	void setAnglularVelocity(float velocity);
	void setVisable(bool visable);
	bool getVisable();
	void setTextured(bool textured);
	float getMinVelocity();
	

	GameObject(Shape* shapePtr, vec3 position, float mass, vec3 velocity, float scale,  vec3 rotationAxis, float rotationAmount, vec3 color, float angularVelocity);

	~GameObject(void);

private:
	Shape* shapePtr;
	vec3 position;
	float mass;
	vec3 velocity;
	float scale;
	vec3 rotationAxis;
	float rotationAmount;
	vec3 force;
	vec3 color;
	bool visable;
	bool textured;
	float angularVelocity;

	/* Don't Modify these values in CODE */

	float minVelocity; 
	float maxVelocity;

	GameObject(void);
	
};

